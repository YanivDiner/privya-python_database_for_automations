import mysql.connector

# Replace these values with your actual database credentials
host = 'localhost'
user = 'myuser'
password = 'egoij3fc1'
database = 'mydatabase'

# Establish a connection
connection = mysql.connector.connect(
    host=host,
    user=user,
    password=password,
    database=database
)

# Create a cursor to interact with the database
cursor = connection.cursor()

# Define user information
username = "john_doe"
email = "john@gmail.com"
password = "mypassword"
bank_account = "654342"
gender = "male"

# Example insert query
insert_query = "INSERT INTO users (username, email, password, bank_account, gender) VALUES (%s, %s, %s, %s, %s)"
user_data = (username, email, password, bank_account, gender)

# Execute the insert query
cursor.execute(insert_query, user_data)

# Commit the transaction
connection.commit()

print("User information inserted into MySQL DB.")

# Close the cursor and connection
cursor.close()
connection.close()
