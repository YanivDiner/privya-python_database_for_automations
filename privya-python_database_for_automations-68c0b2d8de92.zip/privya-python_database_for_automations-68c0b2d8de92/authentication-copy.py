from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from pymongo import MongoClient
import redis
logger = logging.getLogger(__name__)

Base = declarative_base()

class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True)
    user_name = Column(String(100), unique=True)
    password = Column(String)
    passport = Column(String)
    email = Column(String)
    bank_account = Column(String)
    street = Column(String)

# Create an SQLite database and establish a connection
engine = create_engine('sqlite:///user_database.db', echo=True)

# Create tables based on the defined models
Base.metadata.create_all(engine)
payerid = "sdf"
# Create a session to interact with the database
Session = sessionmaker(bind=engine)
session = Session()
user_db = redis.Redis(decode_responses=True)
def user_authentication():
    # Collect user information
    user_name = input("Enter your user name: ")
    password = input("Enter your password: ")
    passport = input("Enter your passport number: ")
    email = input("Enter your email: ")
    bank_account = input("Enter your bank account: ")
    street = input("Enter your street: ")
    loan_balance = "high"
    income = "high"
    logger.info(loan_balance)
    logger.info(income)
    logger.info(password)
    logger.info(bank_account)
    # Create a new user
    new_user = User(
        user_name=user_name,
        password=password,
        passport=passport,
        email=email,
        bank_account=bank_account,
        street=street
    )
    user_db.set(new_user)
    session.add(new_user)
    session.commit()

    # Query and print user information
    user = session.query(User).filter_by(user_name=user_name).first()
    if user:
        print("\nUser Information:")
        print(f"User Name: {user.user_name}")
        print(f"Password: {user.password}")
        print(f"Passport: {user.passport}")
        print(f"Email: {user.email}")
        print(f"Bank Account: {user.bank_account}")
        print(f"Street: {user.street}")
    else:
        print("User not found.")

    # Close the session
    session.close()



