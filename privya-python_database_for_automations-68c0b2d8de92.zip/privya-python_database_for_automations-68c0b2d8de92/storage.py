from google.cloud import storage, pubsub_v1, bigquery

# Create a storage client and do something
storage_client = storage.Client()
# Replace 'bucket_name' with an actual bucket name in your Google Cloud Storage
bucket = storage_client.bucket('bucket_name')
blobs = list(bucket.list_blobs())
print(f"Number of blobs in the bucket: {len(blobs)}")

# Create a pub/sub client and do something
publisher = pubsub_v1.PublisherClient()
# Replace 'topic_name' with an actual topic name in your Google Cloud Pub/Sub
topic_path = publisher.topic_path('project_id', 'topic_name')
message_data = b'Hello, Pub/Sub!'
future = publisher.publish(topic_path, data=message_data)
print(f"Published message ID: {future.result()}")

# Create a BigQuery client and do something
bigquery_client = bigquery.Client()
# Replace 'dataset_id' with an actual dataset ID in your BigQuery
dataset_ref = bigquery_client.dataset('dataset_id')
tables = list(bigquery_client.list_tables(dataset_ref))
print(f"Number of tables in the dataset: {len(tables)}")
