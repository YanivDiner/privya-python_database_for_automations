import boto3

# Create a Boto3 client for S3
s3_client = boto3.client('s3')


def get_file_metadata(key):
    try:
        bucket_name = 'your_bucket_name'
        # Get the metadata of the file
        response = s3_client.head_object(Bucket=bucket_name, Key=key)

        # Extract relevant metadata
        metadata = {
            'Content-Type': response['ContentType'],
            'Content-Length': response['ContentLength'],
            # Add more metadata fields as needed
        }

        return metadata

    except Exception as e:
        print(f"Error: {e}")
        return None


# Example usage
file_key = 'your_file_key'
metadata = get_file_metadata(file_key)
if metadata:
    print("File Metadata:")
    for key, value in metadata.items():
        print(f"{key}: {value}")
else:
    print("Failed to retrieve metadata.")
