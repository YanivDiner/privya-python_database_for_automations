import redis

class A:
    r = redis.Redis()
    address = "Tel Aviv"

    r.set("Address", address, nx=True)

    result = r.get("Address")
