import apache_beam

with apache_beam.Pipeline() as pipeline:
  lines = (
      pipeline
      | apache_beam.Create([
          'To be, or not to be: that is the question: ',
          "Whether 'tis nobler in the mind to suffer ",
          'The slings and arrows of outrageous fortune, ',
          'Or to take arms against a sea of troubles, ',
      ]))