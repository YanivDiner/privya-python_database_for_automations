import logging

from apache_beam import DoFn
from google.cloud import storage

class FreeMailsFilter(DoFn):

    def setup(self):
        self.client = storage.Client()
        freemails_list = "bad-emails/freemail_domain_list.txt"
        bucket = self.client.bucket("zoominfo-sharedmappings")
        freemails_blob = storage.Blob(freemails_list, bucket)