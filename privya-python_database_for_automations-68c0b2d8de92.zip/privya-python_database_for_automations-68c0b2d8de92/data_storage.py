import cx_Oracle

# Replace with your Oracle DB connection details
connection = cx_Oracle.connect(
    user="yair",
    password="a446e6ds55RTG565D==",
    dsn=cx_Oracle.makedsn('145.145.165.157', '1564', service_name='local')
)

# Create a cursor
cursor = connection.cursor()

# Define user information
user_name = "JohnDoe"
password = "password123"
email = "john@gmail.com"
bank_account = "456645"


# Prepare and execute the SQL INSERT statement
insert_sql = "INSERT INTO users (user_name, password, email, bank_account) VALUES (:user_name, :password, :email, :bank_account)"
cursor.execute(insert_sql, {
    'user_name': user_name,
    'password': password,
    'email': email,
    'bank_account': bank_account
})

# Commit the transaction
connection.commit()

# Close the cursor and connection
cursor.close()
connection.close()

print("User information inserted into Oracle DB.")
