from elasticsearch import Elasticsearch

# Create an Elasticsearch client instance
es = Elasticsearch([{'host': 'localhost', 'port': 9200}])

# Define an index and a document for testing
index_name = 'my_index'
document = {
    'title': 'Sample Document',
    'content': 'This is a sample document for Elasticsearch testing.'
}


response = es.index(index=index_name, body=document)

